package com.nikola.primeholdingcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeHoldingCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
