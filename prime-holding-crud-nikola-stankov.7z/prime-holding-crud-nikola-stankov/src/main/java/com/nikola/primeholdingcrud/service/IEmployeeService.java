package com.nikola.primeholdingcrud.service;

import com.nikola.primeholdingcrud.entity.Employee;

import java.util.List;

public interface IEmployeeService {
    List<Employee> findAll();
    Employee findById(int theId);
    void save(Employee employee);
    void deleteById(int theId);
    List<Employee> searchBy(String theName);
}
