package com.nikola.primeholdingcrud.controller;

import com.nikola.primeholdingcrud.dao.EmployeeFeedbackRepository;
import com.nikola.primeholdingcrud.dao.EmployeeRepository;
import com.nikola.primeholdingcrud.dao.TaskRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/statistict")
public class StatisticsController {

    // This is for formatting average salary to have 2 decimal places
    private static final DecimalFormat df = new DecimalFormat("0.00");

    private EmployeeRepository employeeRepository;

    private TaskRepository taskRepository;

    private EmployeeFeedbackRepository employeeFeedbackRepository;
    @Autowired
    public StatisticsController(EmployeeRepository theEmployeeRepository, TaskRepository theTaskRepository, EmployeeFeedbackRepository theEmployeeFeedbackRepository) {
        employeeRepository = theEmployeeRepository;
        taskRepository = theTaskRepository;
        employeeFeedbackRepository = theEmployeeFeedbackRepository;
    }

    @GetMapping("/show")
    public String getStatistics(Model model) {

        long totalEmployees = employeeRepository.count();
        long totalTasks = taskRepository.count();
        long totalFeedback = employeeFeedbackRepository.count();
        Double avgSalary = employeeRepository.findAverageMonthlySalary();

        // This is 3. mandatory functionality from assignment
        List<Object[]> topAssignees = employeeRepository.findTop5AssigneesByTaskCount(LocalDate.now().minusMonths(1), LocalDate.now());

        model.addAttribute("totalEmployees", totalEmployees);
        model.addAttribute("totalTasks", totalTasks);
        model.addAttribute("totalFeedback", totalFeedback);
        model.addAttribute("avgSalary",df.format(avgSalary));
        model.addAttribute("topAssignees",topAssignees);

        return "statistict/statistics";

    }

}
