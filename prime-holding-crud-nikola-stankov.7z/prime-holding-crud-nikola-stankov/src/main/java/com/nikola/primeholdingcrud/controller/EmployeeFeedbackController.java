package com.nikola.primeholdingcrud.controller;

import com.nikola.primeholdingcrud.dao.EmployeeRepository;
import com.nikola.primeholdingcrud.entity.EmployeeFeedback;
import com.nikola.primeholdingcrud.service.IEmployeeFeedbackService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/feedback")
public class EmployeeFeedbackController {
    @Autowired
    private IEmployeeFeedbackService employeeFeedbackService;

    @Autowired
    private EmployeeRepository employeeRepository;


    @GetMapping("/show")
    public String listFeedbacks(Model model) {

        List<EmployeeFeedback> employeeFeedbackList = employeeFeedbackService.findAll();

        model.addAttribute("feedbacks", employeeFeedbackList);

        return "feedbacks/show";
    }
    @GetMapping("/FormForAddingFeedbacks")
    public String showFormForAddingFeedbacks(Model model) {

        EmployeeFeedback theEmployeeFeedback = new EmployeeFeedback();

        model.addAttribute("feedback", theEmployeeFeedback);

        List<Integer> employeeIds = employeeRepository.findAllIds();
        model.addAttribute("employeeIds", employeeIds);

        return "feedbacks/feedback-add-form";

    }

    @PostMapping("/save")
    public String saveFeedback(@ModelAttribute("feedback")EmployeeFeedback theEmployeeFeedback, Model model) {

        employeeFeedbackService.save(theEmployeeFeedback);

        model.addAttribute("feedback", theEmployeeFeedback);

        return "redirect:/feedback/show";

    }

    @GetMapping("/formForUpdateFeedback")
    public String updateFeedback(@RequestParam("feedbackId")int theId, Model model) {

        Optional<EmployeeFeedback> results = Optional.ofNullable(employeeFeedbackService.findById(theId));

        EmployeeFeedback theEmployeeFeedback = null;

        if (results.isPresent()){

            theEmployeeFeedback = employeeFeedbackService.findById(theId);
            List<Integer> employeeIds = employeeRepository.findAllIds();
            model.addAttribute("employeeIds", employeeIds);
        }else {
            throw new RuntimeException("Employee ID not found: "+ theId);
        }

        model.addAttribute("feedback",theEmployeeFeedback);

        return "feedbacks/feedback-update-form";
    }


    @GetMapping("/delete")
    public String deleteFeedback(@RequestParam("feedbackId")int theId) {

        employeeFeedbackService.deleteById(theId);

        return "redirect:/feedback/show";
    }

    @GetMapping("/search")
    public String searchBy(@RequestParam("feedbackName")String theName, Model model) {

        List<EmployeeFeedback> employeeFeedbacks = employeeFeedbackService.searchBy(theName);

        model.addAttribute("feedbacks", employeeFeedbacks);

        return "/feedbacks/show";

    }

}
