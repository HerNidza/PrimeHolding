package com.nikola.primeholdingcrud.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "employee_feedback")
public class EmployeeFeedback {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "positive_description")
    private String positiveDescription;
    @Column(name = "negative_description")
    private String negativeDescription;

    @ManyToOne(fetch = FetchType.LAZY) // Lazy is used for example in our app when we search for some field we would get result that would only be "Me" for example if I searched for me
    @JoinColumn(name = "assigneeF_id")
    private Employee assigneeF;

    public EmployeeFeedback() {

    }

    public EmployeeFeedback(String positiveDescription, String negativeDescription, Employee assigneeF) {
        this.positiveDescription = positiveDescription;
        this.negativeDescription = negativeDescription;
        this.assigneeF = assigneeF;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPositiveDescription() {
        return positiveDescription;
    }

    public void setPositiveDescription(String positiveDescription) {
        this.positiveDescription = positiveDescription;
    }

    public String getNegativeDescription() {
        return negativeDescription;
    }

    public void setNegativeDescription(String negativeDescription) {
        this.negativeDescription = negativeDescription;
    }

    public Employee getAssigneeF() {
        return assigneeF;
    }

    public void setAssigneeF(Employee assigneeF) {
        this.assigneeF = assigneeF;
    }

    @Override
    public String toString() {
        return "EmployeeFeedback{" +
                "id=" + id +
                ", positiveDescription='" + positiveDescription + '\'' +
                ", negativeDescription='" + negativeDescription + '\'' +
                ", assigneeF=" + assigneeF +
                '}';
    }
}
