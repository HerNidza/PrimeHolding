package com.nikola.primeholdingcrud.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = PrefixForNumber.class)
@Target({ElementType.METHOD, ElementType.FIELD}) // METHOD: represents that the annotation can only be applied to method declarations, FIELD: annotation can be applied to a field of a class - like @Column @Id
@Retention(RetentionPolicy.RUNTIME) // It is used to determine how long an annotation type should be retained, whether it should be retained during the compilation process only, or also at runtime.
public @interface PrefixNumber {

    // Define default prefix for number
    String value() default "+359"; // If you wish to change it just delete default and add "value" to my custom validation - also the same for message

    // Define default error message
    String message() default "Mobile Phone should start with +359";

    // Define default groups
    Class<?>[] groups() default {};

    // Define default payloads
    Class<? extends Payload>[] payload() default {};
}
