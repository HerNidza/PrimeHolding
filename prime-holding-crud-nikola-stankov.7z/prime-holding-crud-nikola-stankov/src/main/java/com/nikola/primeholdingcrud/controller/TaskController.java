package com.nikola.primeholdingcrud.controller;

import com.nikola.primeholdingcrud.dao.EmployeeRepository;
import com.nikola.primeholdingcrud.entity.Employee;
import com.nikola.primeholdingcrud.entity.Task;
import com.nikola.primeholdingcrud.service.IEmployeeService;
import com.nikola.primeholdingcrud.service.ITaskService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/tasks")
public class TaskController {


    private ITaskService taskService;
    private IEmployeeService employeeService;
    private EmployeeRepository employeeRepository;

    @Autowired
    public TaskController(ITaskService theTaskService,IEmployeeService theEmployeeService,EmployeeRepository theEmployeeRepository) {
        taskService = theTaskService;
        employeeService = theEmployeeService;
        employeeRepository = theEmployeeRepository;
    }

    @GetMapping("/list")
    public String listTasks(Model model) {

        List<Task> theTasks = taskService.findAll();
        model.addAttribute("tasks", theTasks);
        return "tasks/list-tasks";

    }

    @GetMapping("/FormForAddingTasks")
    public String showFormForAddingTasks(Model model) {

        // Create the model attribute to bind the data
        Task theTask = new Task();
        model.addAttribute("task", theTask);

        List<Integer> employeeIds = employeeRepository.findAllIds();
        model.addAttribute("employeeIds", employeeIds);

        return "tasks/task-form";
    }

    @PostMapping("/save")
    public String saveTask(@Valid @ModelAttribute("task")Task theTask, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()){
            return "tasks/task-form";
        }else {
            // Save the task
            taskService.save(theTask);
            model.addAttribute("task", theTask);
            return "redirect:/tasks/list";

        }
    }

    @GetMapping("/formForUpdateTasks")
    public String updateTask(@RequestParam("taskId")int theId, Model model) {

        // Get the task from the service
        Optional<Task> results = Optional.ofNullable(taskService.findById(theId));

        Task theTask = null;

        if (results.isPresent()){
            theTask = taskService.findById(theId);
            List<Integer> employeeIds = employeeRepository.findAllIds();
            model.addAttribute("employeeIds", employeeIds);
        }else {
            throw new RuntimeException("Employee ID not found: "+ theId);
        }

        model.addAttribute("task", theTask);




        return "tasks/task-form-update";
    }

    @GetMapping("/delete")
    public String deleteTask(@RequestParam("taskId")int theId) {

        // Delete the task
        taskService.deleteById(theId);
        return "redirect:/tasks/list";

    }
    @GetMapping("/search")
    public String searchBy(@RequestParam("taskName")String theName, Model model) {

        List<Task> theTasks = taskService.searchBy(theName);
        model.addAttribute("tasks", theTasks);
        return "/tasks/list-tasks";

    }
}
