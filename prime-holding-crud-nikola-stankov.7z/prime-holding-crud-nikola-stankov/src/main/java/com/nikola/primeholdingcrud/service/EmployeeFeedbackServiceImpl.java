package com.nikola.primeholdingcrud.service;

import com.nikola.primeholdingcrud.dao.EmployeeFeedbackRepository;
import com.nikola.primeholdingcrud.entity.EmployeeFeedback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeFeedbackServiceImpl implements IEmployeeFeedbackService {
    @Autowired
    private EmployeeFeedbackRepository employeeFeedbackRepository;

    @Override
    public List<EmployeeFeedback> findAll() {
        return employeeFeedbackRepository.findAll();
    }

    @Override
    public EmployeeFeedback findById(int theId) {

        Optional<EmployeeFeedback> results = employeeFeedbackRepository.findById(theId);

        EmployeeFeedback theEmployeeFeedback = null;

        if (results.isPresent()){
            theEmployeeFeedback = results.get();
        }else {
            throw new RuntimeException("Could not find department by ID: "+theId);
        }

        return theEmployeeFeedback;
    }

    @Override
    public void save(EmployeeFeedback employeeFeedback) {
        employeeFeedbackRepository.save(employeeFeedback);
    }

    @Override
    public void deleteById(int theId) {
        employeeFeedbackRepository.deleteById(theId);
    }

    @Override
    public List<EmployeeFeedback> searchBy(String theName) {

        List<EmployeeFeedback> results = null;

        if (theName != null && (theName.trim().length() > 0)){
            results = employeeFeedbackRepository.findByPositiveDescriptionContainsOrNegativeDescriptionContainsAllIgnoreCase(theName,theName);
        }else {
            results = findAll();
        }

        return results;
    }
}
