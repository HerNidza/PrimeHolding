package com.nikola.primeholdingcrud.dao;

import com.nikola.primeholdingcrud.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    List<Employee> findByFullNameContainsOrEmailContainsAllIgnoreCase(String name, String lName);
    @Query("SELECT AVG(e.monthlySalary) FROM Employee e")
    Double findAverageMonthlySalary();
    // This is for 3. mandatory functionality
    @Query("SELECT e.fullName, COUNT(*) as tasksCount FROM Task t LEFT JOIN Employee e ON e.id = t.assignee.id WHERE t.dueDate BETWEEN :startDate AND :endDate GROUP BY t.assignee.id ORDER BY tasksCount DESC LIMIT 5")
    List<Object[]> findTop5AssigneesByTaskCount(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    @Query("SELECT e.id FROM Employee e")
    List<Integer> findAllIds();
}


//    SELECT employee.full_name, COUNT(*) as tasksCount
//        FROM task LEFT JOIN employee on (employee.id = task.assignee_id)
//        WHERE due_date BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) AND CURRENT_DATE()
//        GROUP BY task.assignee_id
//        ORDER BY tasksCount DESC
//        LIMIT 5

//@Query("SELECT e.fullName, COUNT(*) as tasksCount FROM Task t LEFT JOIN Employee e on (e.id = t.assignee.id) WHERE t.dueDate >= (CURRENT_DATE() - 30) AND t.dueDate <= CURRENT_DATE() GROUP BY t.assignee.id ORDER BY tasksCount DESC LIMIT 5")
//    @Query("SELECT e.fullName, COUNT(*) as tasksCount FROM Task t LEFT JOIN Employee e on (e.id = t.assignee.id) GROUP BY t.assignee.id ORDER BY tasksCount DESC LIMIT 5")
//    Object[] findTopFive();