package com.nikola.primeholdingcrud.service;

import com.nikola.primeholdingcrud.entity.EmployeeFeedback;

import java.util.List;

public interface IEmployeeFeedbackService {

    List<EmployeeFeedback> findAll();
    EmployeeFeedback findById(int theId);

    void save(EmployeeFeedback employeeFeedback);
    void deleteById(int theId);
    List<EmployeeFeedback> searchBy(String theName);

}
