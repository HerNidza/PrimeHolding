package com.nikola.primeholdingcrud.dao;

import com.nikola.primeholdingcrud.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface TaskRepository extends JpaRepository<Task, Integer> {

    // This is for search field in Tasks - you can search via Title or Description
    List<Task> findByTitleContainsOrDescriptionContainsAllIgnoreCase(String titleName, String descriptionName);

}
