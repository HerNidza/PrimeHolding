package com.nikola.primeholdingcrud.controller;

import com.nikola.primeholdingcrud.entity.Employee;
import com.nikola.primeholdingcrud.service.IEmployeeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    private IEmployeeService employeeService;

    @GetMapping("/list")
    public String listEmployees(Model model) {

         List<Employee> theEmployees = employeeService.findAll();

         // Add to the Spring model - for Thymeleaf
        model.addAttribute("employees",theEmployees);

        return "employees/list-employees";
    }

    @GetMapping("/formForAddingEmployees")
    public String showFormForAddingEmployees(Model model) {

        // Create the model attribute to bind the data
        Employee theEmployee = new Employee();

        model.addAttribute("employee", theEmployee);

        return "employees/employee-add-form";

    }
    @PostMapping("/save")
    public String saveEmployee(@Valid @ModelAttribute("employee") Employee theEmployee,BindingResult bindingResult ,Model model) {

        if (bindingResult.hasErrors()){

            return "employees/employee-add-form";

        }else {
            // Save the employee
            employeeService.save(theEmployee);

            model.addAttribute("employee", theEmployee);

            // User redirect to prevent duplicate submissions
            return "redirect:/employees/list";
        }
    }

    @GetMapping("/formForUpdateEmplyees")
    public String updateEmplyee(@RequestParam("employeeId")int theId, Model model) {

        // Get the Emplyee from the service
        Employee theEmplyee = employeeService.findById(theId);

        // Set employee as model attribute to pre-populate the form
        model.addAttribute("employee",theEmplyee);

        // Send over to our form
        return "employees/employee-add-form";
    }

    @GetMapping("/delete")
    public String deleteEmplyee(@RequestParam("employeeId")int theId) {

        // Delete the employee
        employeeService.deleteById(theId);

        // Redirect to /employee/list
        return "redirect:/employees/list";
    }
    @GetMapping("/search")
    public String searchName(@RequestParam("employeeName") String theName,
                             Model theModel){
        List<Employee> theEmployees = employeeService.searchBy(theName);

        theModel.addAttribute("employees", theEmployees);

        return "/employees/list-employees";
    }
}
