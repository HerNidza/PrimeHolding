package com.nikola.primeholdingcrud.service;

import com.nikola.primeholdingcrud.dao.TaskRepository;
import com.nikola.primeholdingcrud.entity.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskServiceImpl implements ITaskService {
    @Autowired
    private TaskRepository taskRepository;


    @Override
    public List<Task> findAll() {
       return taskRepository.findAll();
    }

    @Override
    public Task findById(int theId) {

        Optional<Task> result = taskRepository.findById(theId);

        Task task = null;

        if (result.isPresent()){
            task = result.get();
        }else {
            throw new RuntimeException("Did not find the Task with ID: "+ theId);
        }

        return task;

    }

    @Override
    public void save(Task task) {
        taskRepository.save(task);
    }

    @Override
    public void deleteById(int theId) {
        taskRepository.deleteById(theId);
    }

    @Override
    public List<Task> searchBy(String theName) {
        List<Task> results = null;

        if (theName != null && (theName.trim().length() > 0)){
            results = taskRepository.findByTitleContainsOrDescriptionContainsAllIgnoreCase(theName,theName);
        }else {
            results = findAll();
        }

        return results;
    }
}
