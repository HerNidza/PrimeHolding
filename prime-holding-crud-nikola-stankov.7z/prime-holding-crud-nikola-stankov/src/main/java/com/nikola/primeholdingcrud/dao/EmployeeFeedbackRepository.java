package com.nikola.primeholdingcrud.dao;

import com.nikola.primeholdingcrud.entity.EmployeeFeedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeFeedbackRepository extends JpaRepository<EmployeeFeedback, Integer> {

    // This is for search field in EmployeeFeedback - you are able to search positive and negative feedbacks
    List<EmployeeFeedback> findByPositiveDescriptionContainsOrNegativeDescriptionContainsAllIgnoreCase(String posFeed, String negFeed);

}
