package com.nikola.primeholdingcrud.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.validator.constraints.Range;
import org.springframework.cglib.core.Local;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Table(name = "task")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id") // Mapping columns
    private Integer id;
    @Size(min = 1, max = 50, message = "Title must have at least 1 character or maximum of 50 characters - Please go back to previous page (click back button) so 'Select' can bind id :) ")
    @Column(name = "title")
    private String title;
    @Size(min = 1, max = 255, message = "Description must have at least 1 character or maximum of 255 characters - Please go back to previous page (click back button) so 'Select' can bind id :)")
    @Column(name = "description")
    private String description;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id")
    private Employee assignee;

    @Future(message = "Due date must be in future - Please go back to previous page (click back button) so 'Select' can bind id :)")
    @NotNull(message = "Due date is required - Please go back to previous page (click back button) so 'Select' can bind id :)")
    @DateTimeFormat(pattern = "dd-MM-yyyy") // Formatting the date
    @Column(name = "due_date")
    private LocalDate dueDate;

    public Task() {

    }

    public Task(Integer id, String description, Employee assignee, LocalDate dueDate) {
        this.id = id;
        this.description = description;
        this.assignee = assignee;
        this.dueDate = dueDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Employee getAssignee() {
        return assignee;
    }

    public void setAssignee(Employee assignee) {
        this.assignee = assignee;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }


    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", assignee=" + assignee +
                ", dueDate=" + dueDate +
                '}';
    }
}
