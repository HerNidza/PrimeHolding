package com.nikola.primeholdingcrud.service;

import com.nikola.primeholdingcrud.entity.Employee;
import com.nikola.primeholdingcrud.entity.Task;
import org.springframework.stereotype.Service;

import java.util.List;


public interface ITaskService {
    List<Task> findAll();
    Task findById(int theId);
    void save(Task task);
    void deleteById(int theId);
    List<Task> searchBy(String theName);



}
