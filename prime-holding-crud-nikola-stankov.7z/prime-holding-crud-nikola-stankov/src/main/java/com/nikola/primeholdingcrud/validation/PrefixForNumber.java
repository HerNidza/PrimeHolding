package com.nikola.primeholdingcrud.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PrefixForNumber implements ConstraintValidator<PrefixNumber, String> {

    private String phonePrefix;

    @Override
    public boolean isValid(String theCode, ConstraintValidatorContext constraintValidatorContext) {

        boolean result;

        if (theCode!=null){
            result = theCode.startsWith(phonePrefix);
        }else {
            return true;
        }
        return result;
    }

    @Override
    public void initialize(PrefixNumber thePrefixNumber) {
        phonePrefix = thePrefixNumber.value();
    }
}
